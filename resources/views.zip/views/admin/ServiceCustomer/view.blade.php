@extends('layouts.admin')

@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Service Customers</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <div class="card-body">


        <div class="row">
<div class="col-md-10">
    <form role="form" method="get"  action="{{route('home')}}">
        @csrf
        <div class="row">

        <div class="col-md-6">
                <div class="form-group">
                    <label>Type</label>
                        <select name="type" class="form-control">
                            <option value="1">Mobile</option>
                            <option value="2">Name</option>
                        </select>
                </div>  
                                 
                <div class="form-group">
                    <label>value</label>
                    <input type="text" name="value" class="form-control">
                </div>
 
                <div class="form-group"> 
                    <button type="submit" name="searchxx"  class="btn btn-danger">Search</button>
                 
                </div>
                    
                </div>


        </div>
    </form>
</div>
</div>



                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Service</th>
                    <th>Vendor Name</th>
                    <th>Isactive</th>
                   <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
				  @foreach($srcustomers as $data)
                  <tr>
                      <td>{{$data->name}}</td>
                      <td>{{$data->mobile}}</td>
                      <td>{{$data->service->title ??''}}</td> 
                      <td>{{$data->vendors->name ??''}}</td> 
                      
                       <td>
                        @if($data->status==1)
                               <span><a href="#" class="btn btn-success">Active</a></span>
                             @else
                               <span style="color:red"><a href="#" class="btn btn-danger">Inactive</a></span>
                             @endif
                       </td>
                        <td><a href="#" class="btn btn-warning">View</a></td>
                     
                 </tr>
                 @endforeach
                  </tbody>
                  <tfoot>
                      <tr>
                        <td colspan="6"> {{$srcustomers->appends(request()->input())->links()}}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

    </div>

@endsection

@section('scripts')

     

@endsection
